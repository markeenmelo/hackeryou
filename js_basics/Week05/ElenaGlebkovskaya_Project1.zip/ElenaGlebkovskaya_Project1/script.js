$(document).ready(function(){
  // Options of games choices
   const gameOptions = ['paper','scissors','rock'];
   // Get random numbers
	 const randomNumber = (number) => {
      return Math.floor(Math.random() * number);
  };
 // Get random computer game choice
  const i = randomNumber(gameOptions.length);
  let option = gameOptions[i];
  const randomOption = (gameOptions) => {
        return option;
  };
  // Setting the Scoreboard
  let countOfPersonWins = 0;
  let countOfComputerWins = 0;
  let countOfTies = 0;
   // Game form to start game on submit
  $('form').on('submit',function(event) {
      event.preventDefault();
      // Get the player's choice and make it lower case
      let myMove = $('input[type=text]').val();
      let myMoveLower = myMove.toLowerCase();
      // Show player choice and computer random choice
      $('.yourResult').text(myMoveLower);
      const i = randomNumber(gameOptions.length);
      option = gameOptions[i];
      // Show the game result
      $('.myResult').text(option);
      $('.submit').removeClass('colorChangeSubmit');
      $('.submit').val('Play!');
      // Calculating the result
      if (myMoveLower != "paper" && myMoveLower != "rock" && myMoveLower != "scissors"){
          // Not Showing choice icons 
          $('.fa-hand-rock.per').addClass('notshow');
  	    	$('.fa-hand-rock.per').removeClass('show');
  	    	$('.fa-hand-peace.per').addClass('notshow');
  	    	$('.fa-hand-peace.per').removeClass('show');
  	    	$('.fa-hand-paper.per').addClass('notshow');
  	    	$('.fa-hand-paper.per').removeClass('show');
          // If incorrect option in submitted show:
      		$('.yourResult').text("Oops! What is this?");
      	 	$('.result').text("Choose rock, paper or scissors");
          // Not show smileys
          $('.tieSmiley').addClass('notshow');
          $('.tieSmiley').removeClass('show');
          $('.nervioussmiley').addClass('notshow');
          $('.nervioussmiley').removeClass('show');
          $('.happysmiley').addClass('notshow');
          $('.happysmiley').removeClass('show');
    	} else if( myMoveLower === option){
          // Show text and icons for the tie
          $('.result').text("We have a tie! Try again?");
          $('.tieSmiley').addClass('show');
          $('.tieSmiley').removeClass('notshow');
          $('.nervioussmiley').addClass('notshow');
          $('.nervioussmiley').removeClass('show');
          $('.happysmiley').addClass('notshow');
          $('.happysmiley').removeClass('show');
          // Update the Scoreboard for tie
          countOfTies++;
      } else  if(myMoveLower ==="rock"){
          if(option==="scissors"){
             // Player win text and happy smiley and update Scoreboard
              $('.result').text("You win! Play again?");
              countOfPersonWins++;
              $('.tieSmiley').addClass('notshow');
              $('.tieSmiley').removeClass('show');
              $('.nervioussmiley').addClass('notshow');
              $('.nervioussmiley').removeClass('show');
              $('.happysmiley').addClass('show');
              $('.happysmiley').removeClass('notshow');
      }else{
          // Player lose text and sad smiley and update scoreboard
           $('.result').text("Sorry, you lose! Try again?");
           countOfComputerWins++;
           $('.tieSmiley').addClass('notshow');
           $('.tieSmiley').removeClass('show');
           $('.nervioussmiley').addClass('show');
           $('.nervioussmiley').removeClass('notshow');
           $('.happysmiley').addClass('notshow');
           $('.happysmiley').removeClass('show');
      }
      }else if(myMoveLower ==="paper"){
          if(option==="rock"){
              // Show player win text and happy smiley and update scoreboard
              $('.result').text("You win! Play again?");
              countOfPersonWins++;
              $('.tieSmiley').addClass('notshow');
              $('.tieSmiley').removeClass('show');
              $('.nervioussmiley').addClass('notshow');
              $('.nervioussmiley').removeClass('show');
              $('.happysmiley').addClass('show');
              $('.happysmiley').removeClass('notshow');
        } else{
          // Player lose text and sad smiley and update Scoreboard
           $('.result').text("Sorry, you lose! Try again?");
           countOfComputerWins++;
           $('.tieSmiley').addClass('notshow');
           $('.tieSmiley').removeClass('show');
           $('.nervioussmiley').addClass('show');
           $('.nervioussmiley').removeClass('notshow');
           $('.happysmiley').addClass('notshow');
           $('.happysmiley').removeClass('show');
        }
      } else if(myMoveLower ==="scissors"){
          if(option==="rock"){
            // Player lose text and sad smiley and update Scoreboard
              $('.result').text("You lose! Try again?");
              countOfComputerWins++;
              $('.tieSmiley').addClass('notshow');
              $('.tieSmiley').removeClass('show');
              $('.nervioussmiley').addClass('show');
              $('.nervioussmiley').removeClass('notshow');
              $('.happysmiley').addClass('notshow');
              $('.happysmiley').removeClass('show');
        } else{
          // Show player win text and happy smiley and update scoreboard
           $('.result').text("You win! Play again?");
           countOfPersonWins++;
           $('.tieSmiley').addClass('notshow');
           $('.tieSmiley').removeClass('show');
           $('.nervioussmiley').addClass('notshow');
           $('.nervioussmiley').removeClass('show');
           $('.happysmiley').addClass('show');
           $('.happysmiley').removeClass('notshow');
        }
      }; 
      myMove = $('input[type=text]').val('');
      const winHappened = () =>{
            $('.youWin').removeClass('numberColor');
            $('.computerWin').removeClass('numberColor');
            $('.result').removeClass('colorChange');
            countOfComputerWins = 0;
            countOfPersonWins = 0;
            countOfTies = 0;
        };
      if (countOfPersonWins === 5){
          // Colorful animation for result text and number when player win 5 rounds
     	    $('.result').text("Yay, you win 5 rounds!!!");
          $('.youWin').addClass('numberColor');
          $('.result').addClass('colorChange');
          setTimeout(winHappened,5000);
          $('.submit').addClass('colorChangeSubmit');
          $('.submit').val('Play again?');
        
     } else if (countOfComputerWins === 5){
          // Colorful animation for result text and number when computer win 5 rounds
     	    $('.result').text("Oh, I win 5 rounds!!!");
          $('.computerWin').addClass('numberColor');
          $('.result').addClass('colorChange')
          setTimeout(winHappened,5000);
          $('.submit').addClass('colorChangeSubmit');
          $('.submit').val('Play again?');

     // } else if (countOfPersonWins >= 5 || countOfComputerWins >= 5){
          // Removing animation and setting scoreboard to 0
          // setTimeout(winHappened,5000);
        
     };
     // Showing the icon of player choice
     if(myMoveLower ==="rock"){
         $('.fa-hand-rock.per').removeClass('notshow');
    	   $('.fa-hand-rock.per').addClass('show');
    	   $('.fa-hand-peace.per').addClass('notshow');
    	   $('.fa-hand-peace.per').removeClass('show');
    	   $('.fa-hand-paper.per').removeClass('show');
    	   $('.fa-hand-paper.per').addClass('notshow');
    } else if(myMoveLower ==="paper"){
        	$('.fa-hand-rock.per').addClass('notshow');
        	$('.fa-hand-rock.per').removeClass('show');
        	$('.fa-hand-peace.per').addClass('notshow');
        	$('.fa-hand-peace.per').removeClass('show');
        	$('.fa-hand-paper.per').addClass('show');
        	$('.fa-hand-paper.per').removeClass('notshow');
    } else if(myMoveLower ==="scissors"){
        	$('.fa-hand-rock.per').addClass('notshow');
        	$('.fa-hand-rock.per').removeClass('show');
        	$('.fa-hand-peace.per').addClass('show');
        	$('.fa-hand-peace.per').removeClass('notshow');
        	$('.fa-hand-paper.per').addClass('notshow');
        	$('.fa-hand-paper.per').removeClass('show');
    };
    // Showing the icon of computer choice
    if(option==="rock"){
         	$('.fa-hand-rock.comp').removeClass('notshow');
        	$('.fa-hand-rock.comp').addClass('show');
        	$('.fa-hand-peace.comp').addClass('notshow');
        	$('.fa-hand-peace.comp').removeClass('show');
        	$('.fa-hand-paper.comp').removeClass('show');
        	$('.fa-hand-paper.comp').addClass('notshow');
    } else if(option==="paper"){
         	$('.fa-hand-rock.comp').addClass('notshow');
        	$('.fa-hand-rock.comp').removeClass('show');
        	$('.fa-hand-peace.comp').addClass('notshow');
        	$('.fa-hand-peace.comp').removeClass('show');
        	$('.fa-hand-paper.comp').addClass('show');
        	$('.fa-hand-paper.comp').removeClass('notshow');
     } else if(option === "scissors"){
         	$('.fa-hand-rock.comp').addClass('notshow');
        	$('.fa-hand-rock.comp').removeClass('show');
        	$('.fa-hand-peace.comp').addClass('show');
        	$('.fa-hand-peace.comp').removeClass('notshow');
        	$('.fa-hand-paper.comp').addClass('notshow');
        	$('.fa-hand-paper.comp').removeClass('show');
     };
     // Showing the Scores on Scoreboard
       $('.youWin').text(countOfPersonWins);
       $('.computerWin').text(countOfComputerWins);
       $('.tieWin').text(countOfTies);
        });
});
      